// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("misra check\n", stdout);
  return lionss_run_workload("misra-check");
}
