// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("doxygen\n", stdout);
  return lionss_run_workload("doxygen");
}
