// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("tidy bugprone"); }
int main(){
  announce();
  return lionss_run_workload("tidy-bugprone");
}
