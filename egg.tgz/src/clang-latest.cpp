// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("clang latest"); }
int main(){
  announce();
  return lionss_run_workload("clang-latest");
}
